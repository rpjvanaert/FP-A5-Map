FP-A5-Map

![](Resources/TiledMap_Module_Class_Diagram.jpg)
the class diagram for the loading of the tiled map