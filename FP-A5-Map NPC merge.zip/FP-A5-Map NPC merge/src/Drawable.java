import org.jfree.fx.FXGraphics2D;

public interface Drawable {

    /**
     * @param graphics
     */
    void draw(FXGraphics2D graphics);

}