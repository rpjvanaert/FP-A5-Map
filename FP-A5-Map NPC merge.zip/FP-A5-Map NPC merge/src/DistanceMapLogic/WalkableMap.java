package DistanceMapLogic;

public class WalkableMap {
    private Boolean[][] walkableMap;

    public WalkableMap(Boolean[][] walkableMap) {
        this.walkableMap = walkableMap;
    }

    public Boolean[][] getMap() {
        return walkableMap;
    }
}
