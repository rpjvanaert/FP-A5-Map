package DistanceMapLogic;

public class Simulator {
}
